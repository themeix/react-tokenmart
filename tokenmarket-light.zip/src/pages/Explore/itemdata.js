export const products=[
    {
        img:"assets/images/product/15.jpg",
        name:"Cyber Boss #12",
    },
    {
        img:"assets/images/product/2.gif",
        name:"Commander  #04",
    },
    {
        img:"assets/images/product/3.gif",
        name:"Mega City Artwork",
    },
    {
        img:"assets/images/product/4.gif",
        name:"Creative  #04",
    },
    {
        img:"assets/images/product/4.gif",
        name:"Creative  #04",
    },
    {
        img:"assets/images/product/20.jpg",
        name:"Commander  #05",
    },
    {
        img:"assets/images/product/20.jpg",
        name:"Commander  #05",
    },
    {
        img:"assets/images/product/21.jpg",
        name:"Creative Oilpaint #07",
    },
    {
        img:"assets/images/product/5.gif",
        name:"Flower Artwork #01",
    },
    {
        img:"assets/images/product/6.gif",
        name:"Creative Mega City",
    },
    {
        img:"assets/images/product/25.jpg",
        name:"Flower Artwork #02",
    },
    {
        img:"assets/images/product/7.gif",
        name:"Creative Oilpaint #07",
    },
    {
        img:"assets/images/product/15.jpg",
        name:"Cyber Boss #12",
    },
    {
        img:"assets/images/product/2.gif",
        name:"Commander  #04",
    },
    {
        img:"assets/images/product/3.gif",
        name:"Mega City Artwork",
    },
    {
        img:"assets/images/product/4.gif",
        name:"Creative  #04",
    },
    {
        img:"assets/images/product/4.gif",
        name:"Creative  #04",
    },
]