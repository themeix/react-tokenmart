export const wallets = [
  {
    img: "assets/images/wallet/2.jpg",
    title: "Trustee Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },

  {
    img: "assets/images/wallet/3.jpg",
    title: " CoinPayments Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },
  {
    img: "assets/images/wallet/4.jpg",
    title: "SwirlWallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },
  {
    img: "assets/images/wallet/5.jpg",
    title: "Trezor Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },

  {
    img: "assets/images/wallet/6.jpg",
    title: " Nuri Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },

  {
    img: "assets/images/wallet/7.jpg",
    title: "  SpectroCoin Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },

  {
    img: "assets/images/wallet/8.jpg",
    title: "  CoolWallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },

  {
    img: "assets/images/wallet/9.jpg",
    title: " SecuX Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },
  {
    img: "assets/images/wallet/10.jpg",
    title: "  Amon Wallet",
    description:
      "Devious the by advantage that might his ship alone, endeavours for or understanding their we more tyrannize. Every forest are findings. More or sitting to and seemed to option text like ",
  },
];
